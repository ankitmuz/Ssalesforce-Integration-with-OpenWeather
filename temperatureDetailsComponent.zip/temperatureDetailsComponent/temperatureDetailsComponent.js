import { LightningElement  } from 'lwc';
import getWeatherDetails from "@salesforce/apex/WeatherDetailsClass.getWeatherDetails"

export default class TemperatureDetailsComponent extends LightningElement {
    cityname='';
    output;
    error;
    temp;
    tempfahrenheit;
    tempCelsius;
    name;
    displayOutput= false;

    handlechange(event){
        this.cityname = event.target.value;
    }

    onclickhandler(){
        getWeatherDetails({cityName: this.cityname})
        .then(data=>{
            this.output = data;
            this.temp = this.output.temp;
            console.log(this.temp);
            console.log(data);
            
            //Kelvin to fahrenheit conversion
            this.tempfahrenheit =(this.output.temp - 273.15)* 9/5 + 32;

            //Kelvin to celsius conversion
            this.tempCelsius = (this.output.temp - 273.15);

            this.name = this.output.name
            this.displayOutput = this.output

            //Kelvin to fahrenheit conversion
            	this.tempfahrenheit =(temp - 273.15)* 9/5 + 32;


            console.log('button calling inside then',JSON.stringify(this.output));
            console.log('button calling inside then',this.output);
        })
        .catch((error) =>{
            this.error=error

            console.log('Error coming while featch data',JSON.stringify(error));
        })
        
    }
}